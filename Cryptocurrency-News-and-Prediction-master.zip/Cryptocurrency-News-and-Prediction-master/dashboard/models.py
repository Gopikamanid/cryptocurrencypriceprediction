from django.db import models

# Create your models here.
class coins(models.Model):
    name=models.TextField(max_length=20)
    details=models.TextField(max_length=500)


class chat(models.Model):
    botreply = models.CharField(max_length=200)
    response = models.CharField(max_length=200)  # Assuming there is a response field

    def __str__(self):
        return self.botreply