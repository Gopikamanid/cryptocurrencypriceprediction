-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: crypto
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dashboard_coins`
--

DROP TABLE IF EXISTS `dashboard_coins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_coins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `details` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_coins`
--

LOCK TABLES `dashboard_coins` WRITE;
/*!40000 ALTER TABLE `dashboard_coins` DISABLE KEYS */;
INSERT INTO `dashboard_coins` VALUES (1,'hai','hello'),(2,'btc','Bitcoin is a form of digital cash that eliminates the need for central authorities such as banks or governments. Instead, Bitcoin uses a peer-to-peer internet network to confirm purchases directly between users.Blockchain: Bitcoin is powered by open-source code known as blockchain, which creates a shared public history of transactions organized into \"blocks\" that are \"chained\" together to prevent tampering. This technology creates a permanent record of each transaction, and it provides a way for every Bitcoin user to operate with the same understanding of who owns what.Private and public keys: A Bitcoin wallet contains a public key and a private key, which work together to allow the owner to initiate and digitally sign transactions. This unlocks the central function of Bitcoin — securely transferring ownership from one user to another.Bitcoin mining: Users on the Bitcoin network verify transactions through a process known as mining, which is designed to confirm that new transactions are consistent with other transactions that have been completed in the past. This ensures that you can’t spend a Bitcoin you don’t have, or that you have previously spent.'),(3,'xrp','XRP is the native cryptocurrency for products developed by Ripple Labs. Its products are used for payment settlement, asset exchange, and remittance systems that work more like SWIFT, a service for international money and security transfers used by a network of banks and financial intermediaries.XRP, its cryptocurrency, was launched in the same year with 80 billion tokens going to the company and 20 billion to its co-founders. The purpose of XRP was to serve as an intermediate mechanism of exchange between two currencies or networks. OpenCoin became Ripple Labs in September 2013.'),(4,'bch','Bitcoin Cash (BCH) is an altcoin version of the popular Bitcoin cryptocurrency. Bitcoin Cash is the result of a hard fork in blockchain technology. One of the most significant changes from Bitcoin to Bitcoin Cash is the size of the coin.Bitcoin Cash trades on digital currency exchanges including Bitstamp, Coinbase, Gemini, Kraken and ShapeShift, using the Bitcoin Cash name and the BCH ticker symbol.'),(5,'eos','EOS is a blockchain-based, decentralized platform used to develop, host, and run business applications, or dApps.EOS launched In June 2018 after an initial coin offering that raised $4.1 billion in crypto for Block.one, the company that developed the open-source software called EOS.IO that is used on the platform.EOS is a blockchain-based platform that enables the development of business applications, or DApps.EOS supports secure access and authentication, permissioning, data hosting, usage management, and communication between the DApps and the Internet.'),(6,'lts','Litecoin (LTC) is an alternative cryptocurrency created in October 2011 by Charles \"Charlie\" Lee, a former Google engineer. Litecoin was adapted from Bitcoin\'s open-source code but with several modifications. Like Bitcoin, Litecoin is based on an open-source global payment network that is not controlled by any central authority. Litecoin differs from Bitcoin in aspects like faster block generation rate and use of Scrypt as a proof of work scheme.Initially, it was a strong competitor to Bitcoin. However, as the cryptocurrency market has become much more saturated and competitive in recent years with new offerings, Litecoin\'s popularity has waned somewhat.'),(7,'link','Chainlink (LINK) is a cryptocurrency and technology platform that enables non-blockchain enterprises to securely connect with blockchain platforms. Chainlink is middleware that connects blockchain-based smart contracts with external data, such as baseball scores or stock prices.The Beginner\'s Guide. Chainlink is a cryptocurrency aiming to incentivize a global network of computers to provide reliable, real-world data to smart contracts running on top of blockchains. If you\'re unfamiliar, smart contracts are agreements programmed to execute if and when certain conditions are met.'),(8,'bnb','Binance Coin is the cryptocurrency issued by the Binance exchange and trades with the BNB symbol. BNB was initially based on the Ethereum network but is now the native currency of Binance\'s own blockchain, the Binance chain.Despite the crypto winter of 2018, BNB has proven resilient in the altcoin markets – and fast forward to 2022, binance coin\'s price still carries a lot of interest. The coin gained roughly 1,344% in 2021, according to Arcane Research, compared to a 73% increase for bitcoin and 455% for ethereum.'),(9,'trx','Tron is a blockchain-based decentralized digital platform with its own cryptocurrency, called Tronix or TRX. Founded in 2017 by a Singapore non-profit organization, the Tron Foundation, Tron aims to host a global entertainment system for the cost-effective sharing of digital content.First, you will need to purchase a coin such as Bitcoin or Ethereum that can be bought with cash. Once you have purchased these coins you can then trade them on an online exchange to receive TRX. Check out our Tron buyer\'s guide for more information or take a look at the Tron price page for historical and prediction data.'),(10,'etc','Ethereum Classic (ETC) is a decentralised, blockchain-based, open-source computing platform, as well as a cryptocurrency. It allows developers to build and deploy smart contracts—autonomous, self-executing code blocks that trigger certain actions based on predefined conditions.Ethereum Classic is a cryptocurrency like Bitcoin. Not to be confused with the cryptocurrency Ethereum, Ethereum Classic functions independently. Ethereum Classic operates using the blockchain and consensus rules that originally governed Ethereum. While Ethereum Classic is among the top cryptocurrencies by market capitalization, its market cap is far smaller than that of Ethereum.'),(11,'eth','Ethereum itself is a blockchain technology platform that supports a wide range of decentralized applications (dApps), including cryptocurrencies. The ETH coin is commonly called Ethereum, although the distinction remains that Ethereum is a blockchain-powered platform, and ether is its cryptocurrency.The token native to the Ethereum blockchain ,Ether (ETH), currently trades around $230, and the market capitalization of all ether around $25 billion, making it the second most valuable blockchain behind Bitcoin (which represents approximately $185 billion of value).');
/*!40000 ALTER TABLE `dashboard_coins` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-30 18:04:56
